import requests
from bs4 import BeautifulSoup
import re
import pandas as pd
import datetime

BASE_URL = "https://news.nate.com/"  # 경제 부분
DEAFAULT_DATE = '20000101'


def get_company_info() :
    req = requests.get(BASE_URL)
    soup = BeautifulSoup(req.text, 'html.parser')
    company_info = soup.find('div', {'class' : 'speechNewsLinkArea f_clear'})
    compant_info_tag = company_info.find_all('li')
    cpList = []

    for a in compant_info_tag :
        href = a.find('a')['href']
        res = re.findall('cp=(\w\w)&', href)[0]
        cpList.append(res)

    return cpList


def make_date_range() :
    '''
    수집년월일을 입력값으로 받아 현재까지의 기사를 수집하는 메소드
    :return: date_range(list, 날짜)
    '''
    init_year = input("시작 일자를 입력하세요.(YYYYMMDD) : ")

    if init_year == '' :
        print(DEAFAULT_DATE[:4] + '년 ' + DEAFAULT_DATE[4 :6] + '월 ' + DEAFAULT_DATE[6 :] + '일부터 수집합니다')
        init_year = DEAFAULT_DATE

    now = datetime.date.today()

    init_day = datetime.date(int(init_year[:4]), int(init_year[4 :6]), int(init_year[6 :]))

    day = init_day
    date_range = list()

    while day <= now :
        date_range.append(day.strftime("%Y%m%d"))
        day += datetime.timedelta(days=1)

    return date_range


def get_total_page_num(cpList, date_range) :
    total_page = list()

    for c in range(0, len(cpList)) :
        total_page_num = dict()
        page_num = list()

        for i in range(0, len(date_range)) :
            req = requests.get('https://news.nate.com/MediaList?cp={cp}&mid=n1101&type=c&date={date}&page=1000'
                               .format(cp=cpList[c], date=date_range[i]))

            soup = BeautifulSoup(req.text, 'html.parser')

            is_valid = True if soup.find('span', {'class' : 'page'}) else False

            if is_valid :
                print(cpList[c] + ' / ' + date_range[i] + '의 총 페이지 : ' +
                      soup.find('span', {'class' : 'page'}).text.split('\n')[-2])
                page_num.append(soup.find('span', {'class' : 'page'}).text.split('\n')[-2])

            else :
                page_num.append('0')
                print("기사가 없습니다. ", date_range[i])

            total_page_num['company'] = cpList[c]
            total_page_num['date'] = date_range[i]
            total_page_num['page_num'] = page_num

        total_page.append(total_page_num)

    return total_page


def make_com_in_url(total_page) :
    com_in_url = list()
    for i in range(0, len(total_page)) :
        for j in range(0, len(total_page[i]['page_num'])) :
            c_url = 'https://news.nate.com/MediaList?cp={cp}&mid=n1101&type=c&date={date}&page={page_num}' \
                .format(cp=total_page[i]['company'], date=total_page[i]['date'], page_num=total_page[i]['page_num'][j])
            com_in_url.append(c_url)
    return com_in_url


def make_page_url(com_in_url) :
    page_url = list()
    for i in range(0, len(com_in_url)) :
        for k in range(1, int(com_in_url[i][74 :]) + 1) :
            page_url.append(com_in_url[i].replace(com_in_url[i][69 :], 'page=' + str(k)))
    return page_url


def make_all_page_url(total_page) :
    all_page_url = list()
    com_in_url = make_com_in_url(total_page)
    all_page_url += make_page_url(com_in_url)

    return all_page_url


def find_article_info(all_page_url) :
    all_article_info = list()

    for i in all_page_url :
        r = requests.get(i)
        soup = BeautifulSoup(r.text, 'html.parser')

        article_tag = soup.find_all('div', {'class' : 'mduSubjectList'})

        for j in article_tag :
            all_article_info.append(get_article_info(j))

    return all_article_info


def get_article_info(soup) :
    article_info = dict()
    article_info['title'] = soup.find('strong', {"class" : "tit"}).text
    article_info['article_url'] = 'https:' + soup.find('a', {"class" : "lt1"}).attrs['href']
    article_info['upload_date'] = re.sub('[\t\n]', '', soup.find('span', {"class" : "medium"}).text[4 :])
    article_info['company'] = re.sub('[\t\n]', '', soup.find('span', {"class" : "medium"}).text[:4])

    return article_info


def make_DF(all_article_info) :
    cols = ['article_url', 'company', 'upload_date', 'title']

    dataframe = pd.DataFrame(all_article_info)

    dataframe = dataframe[cols]

    return dataframe


def get_save_article_content(date_range, dataframe) :
    dataframe['content'] = ''

    for i in range(0, len(dataframe)) :
        req = requests.get(dataframe['article_url'][i])
        soup = BeautifulSoup(req.text, 'html.parser')

        is_valid = True if soup.find('div', {'id' : 'realArtcContents'}) else False

        if is_valid :
            dataframe['content'][i] = re.sub("\n|\t", '', soup.find('div', {'id' : 'realArtcContents'}).text)
        else :
            dataframe['content'][i] = ''

    dataframe.to_csv('{0}_{1}.csv'.format(date_range[0], date_range[-1]), index=False)

    return dataframe


def run_step() :
    cpList = get_company_info()
    date_range = make_date_range()
    total_page = get_total_page_num(cpList, date_range)
    all_page_url = make_all_page_url(total_page)
    all_article_info = find_article_info(all_page_url)
    dataframe = make_DF(all_article_info)
    get_save_article_content(date_range, dataframe)

    return dataframe